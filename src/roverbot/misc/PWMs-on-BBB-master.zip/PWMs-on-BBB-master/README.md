PWMs-on-BBB
===========

Control 4 motors using 4 pwms on BBB  

This is a simple test code to get started with 4 pwm control. I have used the BBB to control 4 motors of my quadrotor. Simply load the device overlay provided i.e. the .dtbo file and use the .cpp file. For further information refer to my blog of controlling motors with pwms. The corresponding blog for the description is http://www.nagavenkat.adurthi.com/?p=614
