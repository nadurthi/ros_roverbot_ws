#!/bin/bash

cd /lib/firmware
echo SPI-4SS > /sys/devices/bone_capemgr.8/slots
cd ~/Desktop/codes
