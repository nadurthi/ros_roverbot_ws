#write codes to update flags
#when IMU not available, no flag update....hence measurement update will change
 ...........  same thing with viconflag
# Make onboard controller faster
# sandbox measurements into another thread to remove delays of control
